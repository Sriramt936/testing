package com.example.sri;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SriApplication {

	public static void main(String[] args) {
		SpringApplication.run(SriApplication.class, args);
	}

}
