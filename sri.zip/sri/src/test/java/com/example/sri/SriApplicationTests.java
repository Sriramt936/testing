package com.example.sri;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SriApplicationTests {

	@Test
	void contextLoads() {
	}

}
